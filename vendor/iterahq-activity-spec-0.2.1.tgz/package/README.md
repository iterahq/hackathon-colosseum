# @iterahq/activity-spec

The **single source of truth** for Itera activity `spec` / `rubric` shapes —
per-kind **Zod schemas + inferred TypeScript types**, imported by **both**
[`itera-player`](https://github.com/iterahq/itera-player) (renderer + TEST) and
[`itera-mcp`](https://github.com/iterahq/itera-mcp) (write validation).

It exists to **kill the 3-place enum/shape drift**:

1. the `itera.activity_kind` DB enum (Itera Supabase `kjefmwlopzeaqgqtlbdn`),
2. the `ActivityKind` union in `itera-player:src/types/content.ts`,
3. the `ACTIVITY_KINDS` const + `z.record(z.any())` specs in `itera-mcp:src/tools/activities.ts`.

(2) and (3) become imports of this package; the DB enum stays authoritative for
the database and is mirrored in [`ACTIVITY_KINDS`](./src/kinds.ts).

> Phase 1 (plan `20260706-iterahq-activity-authoring-canvas-testing`, ADR-4)
> covers the **6 no-judge general kinds first**: `concept`, `single_choice`,
> `multi_choice`, `match`, `order`, `video`. `document` / `diagram` and the
> judged `quiz` / `code` are loose passthrough **TODO stubs** to be tightened in
> a follow-up.

## Install

Published to **GitHub Packages** under the `@iterahq` scope. Add to the consumer's
`.npmrc`:

```
@iterahq:registry=https://npm.pkg.github.com
//npm.pkg.github.com/:_authToken=${NODE_AUTH_TOKEN}
```

```bash
pnpm add @iterahq/activity-spec
```

`zod` is a **peer dependency** (`^3.23.0`) — the consumer provides its own zod so
schemas share a single zod instance.

## Usage

```ts
import {
  parseActivitySpec,
  safeParseActivitySpec,
  SingleChoiceSpecSchema,
  ActivitySpecEnvelopeSchema,
  resolveLocale,
  type SingleChoiceSpec,
} from '@iterahq/activity-spec';

// itera-mcp: validate an agent-authored spec before writing
const spec = parseActivitySpec('single_choice', input); // throws ZodError if invalid

// non-throwing
const res = safeParseActivitySpec('match', input);
if (!res.success) return errResult(res.error.message);

// validate the whole { kind, spec } row (discriminated union)
ActivitySpecEnvelopeSchema.parse({ kind: 'order', spec });

// itera-player: resolve bilingual text for the active locale
const label = resolveLocale(option.label, 'pt'); // string | undefined
```

## Bilingual (pt/en) — ADR-9

Activities carry **no `title_i18n` column**; every author-facing string lives in
`spec`. A localizable field ([`LocalizedText`](./src/i18n.ts)) accepts **either**:

- a plain `string` (legacy / single-locale), or
- an `{ pt?, en? }` bag (bilingual; at least one locale present).

`resolveLocale(text, locale, fallback)` picks the variant; `isBilingual(text)` is
the soft conformance signal (flags one-language content — the existing-rows pass
is **audit-and-report only**, never a hard reject).

## The 6 kinds (Phase 1)

| kind | key fields (mirrors the player renderer) |
|---|---|
| `concept` | `{ instruction }` |
| `video` | `{ video_url, instruction? }` |
| `single_choice` | `{ instruction?, options[], correct_option_id }` |
| `multi_choice` | `{ instruction?, options[], correct_option_ids[] }` |
| `match` | `{ instruction?, left[], right[], pairs[] }` (pair = `{ left_id, right_id }`) |
| `order` | `{ instruction?, items[], correct_order[] }` |

Shared primitives: [`InstructionPanelSpec`](./src/primitives.ts)
(`{ text?, audio_url?, image_url?, video_url?, description? }`) and
[`ChoiceOption`](./src/primitives.ts) (`{ id, label?, image_url?, audio_url? }`).

## Develop

```bash
pnpm install
pnpm run typecheck   # tsc --noEmit
pnpm run build       # tsup → dist (ESM + CJS + .d.ts)
pnpm run test        # vitest
```

Versioning is via [changesets](https://github.com/changesets/changesets): add a
changeset in your PR (`pnpm exec changeset`); merging the auto-generated
"Version Packages" PR publishes to GitHub Packages.

## Rollout order (ADR-4, LOCKED)

1. **publish this package**, then
2. `itera-player` imports it (renderer union + TEST), then
3. `itera-mcp` imports it (replaces `ACTIVITY_KINDS` + the `z.record(z.any())`
   spec validation).
